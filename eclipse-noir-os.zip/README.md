# Eclipse Noir OS - hobby x86_64 UEFI kernel (source package)
This archive contains the source scaffolding for *Eclipse Noir OS* — an educational x86_64 UEFI hobby kernel with basic IRQs, PIC/PIT timer, PS/2 keyboard handling, IDT/ISR stubs, simple scheduler, and an initramfs skeleton.

## Build & Run (Linux, Debian/Ubuntu example)
Install dependencies:
```sh
sudo apt update
sudo apt install build-essential nasm gcc-multilib xorriso grub-pc-bin qemu-system-x86 ovmf
```

Build and create ISO:
```sh
make
```

Run in QEMU (UEFI):
```sh
make run
```

Notes:
- This is an educational project; some components (APIC, IOAPIC) are optional and may require tweaks on different hosts.
- If grub-mkrescue fails, ensure `xorriso` and `grub-pc-bin` (or grub2) are installed.
