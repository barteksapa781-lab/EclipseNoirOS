#include <stdint.h>
/* very small cooperative scheduler placeholder */
volatile int current_task = 0;
void schedule_tick() {
    current_task = (current_task + 1) % 1; /* only one demo task for now */
}
