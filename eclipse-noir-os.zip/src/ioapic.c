/* Placeholder: IOAPIC functions - not fully implemented in this package. */
#include <stdint.h>
void ioapic_init() { }
