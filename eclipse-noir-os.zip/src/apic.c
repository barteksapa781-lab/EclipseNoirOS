/* Placeholder: APIC functions - not fully implemented in this package. */
#include <stdint.h>
void apic_init() { }
