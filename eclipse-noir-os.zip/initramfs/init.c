#include <stdio.h>
int main(void) {
    printf("Hello from initramfs!\n");
    return 0;
}
