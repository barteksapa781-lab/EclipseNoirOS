        #include <stdint.h>
        #include "ports.h"
#include "keymap.h"

volatile uint16_t* VGA = (uint16_t*)0xB8000;
static uint16_t cursor_pos = 0;

static inline void vga_putc(char c) {
    if (c == '\n') {
        cursor_pos += 80 - (cursor_pos % 80);
        return;
    }
    if (c == '\b') {
        if (cursor_pos > 0) cursor_pos--;
        VGA[cursor_pos] = (uint16_t)(' ') | (uint16_t)(0x07 << 8);
        return;
    }
    VGA[cursor_pos++] = (uint16_t)c | (uint16_t)(0x07 << 8);
}

static inline void puts(const char* s) {
    while (*s) vga_putc(*s++);
}

#define PIC1_CMD 0x20
#define PIC1_DATA 0x21
#define PIC2_CMD 0xA0
#define PIC2_DATA 0xA1

void pic_remap() {
    uint8_t a1 = inb(PIC1_DATA);
    uint8_t a2 = inb(PIC2_DATA);

    outb(PIC1_CMD, 0x11);
    outb(PIC2_CMD, 0x11);
    outb(PIC1_DATA, 0x20);
    outb(PIC2_DATA, 0x28);
    outb(PIC1_DATA, 0x04);
    outb(PIC2_DATA, 0x02);
    outb(PIC1_DATA, 0x01);
    outb(PIC2_DATA, 0x01);

    outb(PIC1_DATA, a1);
    outb(PIC2_DATA, a2);
}

static inline void pic_eoi(uint8_t irq) {
    if (irq >= 8)
        outb(PIC2_CMD, 0x20);
    outb(PIC1_CMD, 0x20);
}

#define PIT_CMD 0x43
#define PIT_CH0 0x40

static volatile unsigned long tick_count = 0;

void pit_init(unsigned int frequency) {
    unsigned int divisor = 1193180 / frequency;
    outb(PIT_CMD, 0x36);
    outb(PIT_CH0, divisor & 0xFF);
    outb(PIT_CH0, (divisor >> 8) & 0xFF);
}

extern void do_irq0();
extern void do_irq1(uint8_t sc);

void timer_tick() {
    tick_count++;
    if (tick_count % 100 == 0) {
        puts("Tick: ");
        unsigned long v = tick_count;
        char buf[32]; int i=0;
        if (v==0) vga_putc('0');
        while (v>0 && i<31) { buf[i++]= '0' + (v%10); v/=10; }
        while (i--) vga_putc(buf[i]);
        vga_putc('\n');
    }
}

void keyboard_handle(uint8_t scancode) {
    if (scancode & 0x80) return;
    char c = ps2_map[scancode];
    if (c) vga_putc(c);
}

void do_irq0() { timer_tick(); pic_eoi(0); }
void do_irq1(uint8_t sc) { keyboard_handle(sc); pic_eoi(1); }

void irq_init() { pic_remap(); pit_init(100); }
