#include <stdint.h>

struct idt_entry { uint16_t offset_low; uint16_t selector; uint8_t ist; uint8_t type_attr; uint16_t offset_mid; uint32_t offset_high; uint32_t zero; };
struct idt_ptr { uint16_t limit; uint64_t base; };

extern void irq0_stub();
extern void irq1_stub();

static struct idt_entry idt[256];
static struct idt_ptr idtp;

static void set_idt_entry(int n, void(*handler)()) {
    uint64_t addr = (uint64_t)handler;
    idt[n].offset_low = addr & 0xFFFF;
    idt[n].selector = 0x08;
    idt[n].ist = 0;
    idt[n].type_attr = 0x8E;
    idt[n].offset_mid = (addr >> 16) & 0xFFFF;
    idt[n].offset_high = (addr >> 32) & 0xFFFFFFFF;
    idt[n].zero = 0;
}

void idt_init() {
    for (int i=0;i<256;i++) { idt[i].offset_low = 0; idt[i].selector = 0; idt[i].ist = 0; idt[i].type_attr = 0; idt[i].offset_mid = 0; idt[i].offset_high = 0; idt[i].zero = 0; }
    set_idt_entry(32, irq0_stub);
    set_idt_entry(33, irq1_stub);
    idtp.limit = sizeof(idt)-1;
    idtp.base = (uint64_t)&idt;
    asm volatile ("lidt %0" :: "m"(idtp));
}
