#include <stdint.h>
#include "ports.h"

extern void irq_init();
extern void idt_init();
extern char stack_top;

static volatile uint16_t* VGA = (uint16_t*)0xB8000;

void puts(const char* s);
void puts(const char* s) {
    volatile uint16_t* v = VGA; size_t i=0; while (*s) { v[i++] = (uint16_t)(*s++) | (uint16_t)(0x07<<8); }
}

void kmain(void) {
    for (int i=0;i<80*25;i++) VGA[i] = (uint16_t)(' ') | (0x07<<8);
    puts("Eclipse Noir OS - kernel started\n");
    idt_init();
    puts("IDT initialized\n");
    irq_init();
    puts("IRQs initialized\n");
    asm volatile ("sti");
    puts("Type on keyboard to see echoed chars\n");
    for (;;) { asm volatile ("hlt"); }
}
